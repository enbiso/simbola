<?php
namespace application\#MODULE_NAME#;
/**
 * Description of Module Configuration
 *
 * Module 	: #MODULE_NAME#
 * Created	: #TODAY_DATE#
 * Purpose 	: #MODULE_PURPOSE#
 *
 * Change Logs
 * -----------------------------------------------------------
 * #TODAY_DATE# #AUTHER#: Created the module #MODULE_NAME#
 *  
 * @author #AUTHER#
 */
class Config extends \simbola\core\application\AppModuleConfig{
    public function __construct() {
        $this->name("#MODULE_NAME#");        
    }
}

?>
